create function unifyspacesandtrim(chaostext text) returns text
    language plpgsql
as
$$
BEGIN
		-- start by replacing all spaces of any kind with latin 0020
		-- then trim that normal space from the end and beginning
		RETURN regexp_replace(
					regexp_replace(
						regexp_replace(chaostext, '[\s\u180e\u200B\u200C\u200D\u2060\uFEFF\u00a0]',' ','g'), 
						'\s+$',''),
						'^\s+','');
	END;
$$;

alter function unifyspacesandtrim(text) owner to sylvia;

