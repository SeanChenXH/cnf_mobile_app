create function unifyspacechars(chaostext text) returns text
    language plpgsql
as
$$
BEGIN
		RETURN regexp_replace(chaostext, '[\s\u180e\u200B\u200C\u200D\u2060\uFEFF\u00a0]',' ','g'); 
	END;
$$;

alter function unifyspacechars(text) owner to sylvia;

