create function cnf_parsezipcode(zipraw text) returns text
    language plpgsql
as
$$
DECLARE
  		cleanzip TEXT;

	BEGIN
		cleanzip := substring(zipraw FROM '(\d{5})');
		IF cleanzip IS NOT NULL
			THEN
				RETURN cleanzip;
			ELSE
				RETURN '';
		END IF;
	END;
$$;

alter function cnf_parsezipcode(text) owner to sylvia;

